# Week 5 Assignment

Wave Flow Pattern (Class-based version)

Animated circular wave pattern built with HTML Canvas and ES6 Class.

👉 [View in browser (GitHub Pages)](https://ylee32-ops.github.io/my-hello-world-project-2025/w5-assignment/)
